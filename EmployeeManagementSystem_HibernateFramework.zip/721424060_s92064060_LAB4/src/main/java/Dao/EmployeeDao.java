package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import model.Employee;
import util.HibernateUtil;

public class EmployeeDao implements IEmployeeDao {
    @SuppressWarnings("deprecation")
	@Override
    public void save(Employee employee) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start the transaction
            transaction = session.beginTransaction();

            // Save the employee object
            session.save(employee);

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        }
    }

    @Override
    public Employee getById(int id) {
        Transaction transaction = null;
        Employee employee = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start the transaction
            transaction = session.beginTransaction();

            // Retrieve the employee object by ID
            employee = session.get(Employee.class, id);

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        }
        return employee;
    }

    @Override
    public List<Employee> getAll() {
        Transaction transaction = null;
        List<Employee> employees = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start the transaction
            transaction = session.beginTransaction();

            // Retrieve all employees
            employees = session.createQuery("from Employee", Employee.class).list();

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        }
        return employees;
    }

    @SuppressWarnings("deprecation")
	@Override
    public void update(Employee employee) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start the transaction
            transaction = session.beginTransaction();

            // Update the employee object
            session.update(employee);

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        }
    }

    @SuppressWarnings("deprecation")
	@Override
    public void delete(int id) {
        Transaction transaction = null;
        Employee employee = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start the transaction
            transaction = session.beginTransaction();

            // Retrieve the employee object by ID
            employee = session.get(Employee.class, id);

            // Delete the employee object
            if (employee != null) {
                session.delete(employee);
            }

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
        }
    }
}

package Dao;

import java.util.List;
import model.Employee;

public interface IEmployeeDao {
    void save(Employee employee);

    Employee getById(int id);

    List<Employee> getAll();

    void update(Employee employee);

    void delete(int id);
}


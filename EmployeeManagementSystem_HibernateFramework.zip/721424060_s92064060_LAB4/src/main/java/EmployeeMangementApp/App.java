package EmployeeMangementApp;

import java.util.List;
import Dao.EmployeeDao;
import Dao.IEmployeeDao;
import model.Employee;

@SuppressWarnings("unused")
public class App {
    public static void main(String[] args) {
        // Create an instance of the Employee DAO
        IEmployeeDao employeeDao = new EmployeeDao();

        // Create and save an employee
        Employee newEmployee = new Employee("Safran Mohammed", "s92064060@ousl.lk", 50000.0);
        EmployeeDao employeeDao2 = new EmployeeDao();
		employeeDao2.save(newEmployee);

		
		/*
		 
        // Retrieve and display all employees
        System.out.println("All Employees:");
        for (Employee employee : employeeDao.getAll()) {
            System.out.println(employee);
        }

        // Retrieve and display an employee by ID
        int employeeId = 1; // Provide the ID of the employee you want to retrieve
        Employee retrievedEmployee = employeeDao.getById(employeeId);
        if (retrievedEmployee != null) {
            System.out.println("Retrieved Employee:");
            System.out.println(retrievedEmployee);
        } else {
            System.out.println("Employee not found.");
        }

        // Update employee information
        if (retrievedEmployee != null) {
            retrievedEmployee.setSalary(55000.0);
            employeeDao.update(retrievedEmployee);
            System.out.println("Employee updated successfully.");
        }

        // Delete an employee by ID
        int employeeToDeleteId = 1; // Provide the ID of the employee you want to delete
        employeeDao.delete(employeeToDeleteId);
        System.out.println("Employee deleted successfully.");
        */
        
    }
}


